from fastapi import APIRouter, Depends, status, HTTPException
from sqlalchemy.orm import Session
from typing import Annotated
from sqlalchemy import insert
from slugify import slugify

from app.backend.db_depends import get_db
from app.schemas import CreateCategory
from app.models.category import Category
from app.models.products import Product


router = APIRouter(prefix='/categories', tags=['category'])


@router.get('/')
async def get_all_categories():
    pass


@router.post('/', status_code=status.HTTP_201_CREATED)
async def create_category(
        db: Annotated[Session, Depends(get_db)],    # Получаем подключение к БД через Depends
        create_category: CreateCategory             # Данные запроса JSON автоматически валидируются через Pydantic
):
    # Вставка новой категории в таблицу categories с помощью SQLAlchemy insert
    db.execute(
        insert(Category).values(
            name=create_category.name,              # Название категории из тела запроса
            parent_id=create_category.parent_id,    # ID родительской категории (или None)
            slug=slugify(create_category.name)      # автоматическое создание "slug" (/categories/ruchnoy-instrument)
        )
    )
    # Завершаем транзакцию - коммитим изменения в БД
    db.commit()
    # Отправляем ответ клиенту - статус и подтверждение
    return {
        'status code': status.HTTP_201_CREATED,
        'transaction': 'Successful'
    }


@router.put('/')
async def update_category():
    pass


@router.delete('/')
async def delete_category():
    pass
